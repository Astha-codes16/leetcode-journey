<nav class="navbar" id="navbar">
  <div class="navbar-container">
    <div class="logo">
      <a href="index.php">Hotel Paradise</a>
    </div>
    <ul class="nav-links">
      <li>
        <a href="index.php">Home</a>
        <div class="nav-card">
          <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/1c/de/c6/a3/exterior.jpg?w=900&h=-1&s=1" alt="Home" />
          <p>Welcome to Hotel Paradise!</p>
        </div>
      </li>
      <li>
        <a href="rooms.php">Rooms</a>
        <div class="nav-card">
          <img src="https://expressinnindia.com/wp-content/uploads/2024/07/Freesia-God-23.jpg" alt="Rooms" />
          <p>Explore our Deluxe & Luxury Suites.</p>
        </div>
      </li>
      <li>
        <a href="booking.php">Booking</a>
        <div class="nav-card">
          <img src="images/booking_preview.jpg" alt="Booking" />
          <p>Reserve your stay today!</p>
        </div>
      </li>
      <li>
        <a href="restaurant.php">Restaurant</a>
        <div class="nav-card">
          <img src="images/restaurant_preview.jpg" alt="Restaurant" />
          <p>Fine dining, café & buffet specials.</p>
        </div>
      </li>
      <li>
        <a href="services.php">Services</a>
        <div class="nav-card">
          <img src="images/services_preview.jpg" alt="Services" />
          <p>Spa • Gym • Pool • Free Wi-Fi</p>
        </div>
      </li>
      <li>
        <a href="gallery.php">Gallery</a>
        <div class="nav-card">
          <img src="images/gallery_preview.jpg" alt="Gallery" />
          <p>See our beautiful interiors.</p>
        </div>
      </li>
      <li>
        <a href="view_feedback.php">Feedback</a>
        <div class="nav-card">
          <img src="images/feedback_preview.jpg" alt="Feedback" />
          <p>Read guest experiences.</p>
        </div>
      </li>
      <li>
        <a href="contact.php">Contact</a>
        <div class="nav-card">
          <img src="images/contact_preview.jpg" alt="Contact" />
          <p>Reach out to us anytime.</p>
        </div>
      </li>
    </ul>
     
   

    <div class="hamburger">
      <span></span>
      <span></span>
      <span></span>
    </div>
  </div>
</nav>
