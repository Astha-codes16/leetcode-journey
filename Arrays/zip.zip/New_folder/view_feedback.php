
<?php


include 'db.php';
include 'components/header.php';
?>
<section class="feedback-display">
    <h2>Customer Feedback</h2>

    <?php
    // Check if the connection exists
    if (!$conn) {
        echo "<p style='color:red;'>Database connection failed: " . mysqli_connect_error() . "</p>";
        exit;
    }

    // Run the query
    $result = mysqli_query($conn, "SELECT * FROM feedback ORDER BY created_at DESC");

    // Check for query errors
    if (!$result) {
        echo "<p style='color:red;'>Query failed: " . mysqli_error($conn) . "</p>";
        exit;
    }

    // Check if any rows exist
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<div class='feedback-card' style='border:1px solid #ccc; padding:10px; margin:10px 0; border-radius:5px;'>";
            echo "<h3>" . htmlspecialchars($row['name']) . " (" . htmlspecialchars($row['email']) . ") <span>(" . htmlspecialchars($row['rating']) . "⭐)</span></h3>";
            echo "<p>" . htmlspecialchars($row['message']) . "</p>";
            echo "<small>📅 " . htmlspecialchars($row['created_at']) . "</small>";
            echo "</div>";
        }
    } else {
        echo "<p>No feedback available yet.</p>";
    }
    ?>
</section>
    <?php
include 'components/footer.php';     // Footer + JS
?>

