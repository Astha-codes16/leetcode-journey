<!DOCTYPE html>
<html>

<head>
    <title>Services - Hotel Paradise</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <header>
        <h1>Our Services</h1>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="booking.php">Booking</a></li>
                <li><a href="restaurant.html">Restaurant</a></li>
                <li><a href="gallery.html">Gallery</a></li>
                <li><a href="feedback.php">Feedback</a></li>
            </ul>
        </nav>
    </header>

    <section class="services">
        <div class="hover-card">
            <h3>🏋️ Gym</h3>
            <p>Modern equipment available.</p>
        </div>
        
    </section>
</body>

</html>