<?php include 'db.php'; ?>
<?php include 'components/header.php'; ?>

<section class="feedback-section">
  <h2>Feedback Form</h2>

  <form method="POST" action="">
    <label>Name:</label>
    <input type="text" name="name" required><br>

    <label>Email:</label>
    <input type="email" name="email" required><br>

    <label>Rating:</label>
    <select name="rating" required>
      <option value="">--Select Rating--</option>
      <option value="5">⭐⭐⭐⭐⭐ Excellent</option>
      <option value="4">⭐⭐⭐⭐ Good</option>
      <option value="3">⭐⭐⭐ Average</option>
      <option value="2">⭐⭐ Poor</option>
      <option value="1">⭐ Bad</option>
    </select><br>

    <label>Message:</label>
    <textarea name="message" required></textarea><br>

    <input type="submit" name="submit" value="Submit Feedback">
  </form>

 <?php
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $rating = $_POST['rating'];
    $message = $_POST['message'];

    $sql = "INSERT INTO feedback (name, email, rating, message) 
            VALUES ('$name', '$email', '$rating', '$message')";

    if (mysqli_query($conn, $sql)) {
        echo "<p class='success'>✅ Thank you, $name! Your feedback (Rating: $rating⭐) has been submitted.</p>";
    } else {
        // Check if duplicate email error
        if (mysqli_errno($conn) == 1062) {
            echo "<p class='error'>❌ This email ($email) has already submitted feedback. Please use a different email.</p>";
        } else {
            echo "<p class='error'>❌ Error: " . mysqli_error($conn) . "</p>";
        }
    }
}
?>


</section>

<?php include 'components/footer.php'; ?>
