<?php


include 'db.php';
include 'components/header.php';
?>
    <section class="banner">
        <div class="banner-text">
            <h2>Welcome to <span style="color: blue;"> Hotel</span></h2>
            <a href="booking.php" class="btn">Book Now</a>
            <a href="rooms.php" class="btn">View Rooms</a>
        </div>
    </section>

    <?php
include 'components/footer.php';     // Footer + JS
?>
<div style="background-color: lightblue; height:200px">ft</div>