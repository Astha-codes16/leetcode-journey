<?php include 'db.php'; ?>
<?php include 'components/header.php'; ?>
<body>
  <h2>Room Booking</h2>
  <form method="POST" action="">
    <label>Check-in:</label>
    <input type="date" name="checkin" required><br>
    <label>Check-out:</label>
    <input type="date" name="checkout" required><br>
    <label>Room Type:</label>
    <select name="room">
      <option>Single</option>
      <option>Double</option>
      <option>Deluxe</option>
    </select><br>
    <input type="submit" name="book" value="Book Now">
  </form>

  <?php
  if (isset($_POST['book'])) {
      $checkin = $_POST['checkin'];
      $checkout = $_POST['checkout'];
      $room = $_POST['room'];
      echo "<p>✅ Booking confirmed for a <b>$room</b> room from <b>$checkin</b> to <b>$checkout</b>!</p>";
  }
  ?>
</body>
<?php include 'components/footer.php'; ?>
